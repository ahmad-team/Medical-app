---
name: Clinical Clarity
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#424753'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#727785'
  outline-variant: '#c2c6d5'
  surface-tint: '#005ac2'
  primary: '#0050ae'
  on-primary: '#ffffff'
  primary-container: '#1a68d5'
  on-primary-container: '#e9eeff'
  inverse-primary: '#adc6ff'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#774a00'
  on-tertiary: '#ffffff'
  tertiary-container: '#986000'
  on-tertiary-container: '#ffecd9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004495'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  margin: 1rem
  margin-tablet: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.25rem
  space-xl: 1.5rem
---

## Brand & Style

This design system establishes an aura of serene precision, medical-grade authority, and effortless accessibility. Geared toward patients, caretakers, and health managers navigating complex personal health histories, the interface prioritizes calm reassurance over cold clinical austerity. It blends modern corporate reliability with tactile digital product design: clean geometries, spacious structural rhythm, and instantly decipherable status indicators.

The visual style employs crisp, high-contrast surfaces over layered cool-neutral grounds, avoiding visual clutter while delivering immediate readability under high-stress conditions. Subtle ambient elevation, soft pill-shaped interactive targets, and clear categorical color accents allow users to scan test results, prescriptions, and timeline logs with complete trust and zero cognitive friction.

## Colors

The palette is engineered around visual hygiene, high contrast, and unmistakable status signaling:

- **Primary Brand (`#1A68D5` / Deep Sapphire `#0D54CF`):** Signals technological rigor, clinical competence, and digital privacy. Paired with a soft sky tint (`#EBF3FE`) for primary hover fills, selected chips, and primary surface washes.
- **Secondary / Wellness Green (`#10B981`):** Applied to synchronized states, normal lab values, active prescriptions, and verification flags. Soft tint (`#E6F7F0`) serves as the background container.
- **Tertiary / Warning Amber (`#F59E0B`):** Dedicated to upcoming dosage alerts, pending doctor confirmations, and borderline values, backed by amber wash (`#FEF3C7`).
- **Critical / Rose (`#EF4444`):** Strictly reserved for vital alerts, abnormal pathology warnings, allergies, and destructive actions, backed by soft rose (`#FEE2E2`).
- **Neutrals & Surfaces:** Pure White (`#FFFFFF`) forms the elevated card and container surfaces; light atmospheric grey-slate (`#F8FAFC` to `#F1F5F9`) anchors the root canvas; crisp slate borders (`#E2E8F0`) provide optical separation; dark slate text (`#0F172A` high emphasis, `#475569` medium emphasis) ensures strict WCAG AAA legibility.

## Typography

The typography balances friendly approachability with scientific rigor:

- **Headlines and Labels:** Set in **Plus Jakarta Sans** for its warm curves, open apertures, and crisp geometric legibility at glanceable sizes. It conveys human-centered clinical care without feeling overly playful.
- **Body & Numerical Records:** Set in **Inter** to ensure maximum metric clarity, tabular digit alignment, and effortless density handling for dosages, medical notes, and lab figures.
- Large titles scale smoothly down on mobile viewports to prevent awkward wraps of lengthy medical terminology (e.g., "Gastroenterology Consultation").

## Layout & Spacing

This mobile-centric layout uses an adaptable single-column mobile rhythm expanding to dual-pane master-detail flows on tablets and foldable devices. 

- **Canvas Safe Area & Margins:** Standard mobile canvas applies `margin` (16px), keeping content safe from screen edges while maximizing thumb-reachable horizontal room. Tablet increases margins to `margin-tablet` (24px).
- **Rhythm & Gaps:** Nested internal card contents follow a consistent 4px/8px incremental rhythm (`space-xs` = 4px, `space-sm` = 8px, `space-md` = 16px, `space-lg` = 20px, `space-xl` = 24px).
- **Scroll Alignment:** Health timelines enforce a vertical rail line spaced `1rem` from the leading margin, anchoring chronological events with consistent dot indicators.

## Elevation & Depth

Visual depth is structured to minimize anxiety and heighten tactile feedback:

- **Ground Level (Base Canvas):** Set to `#F8FAFC`, creating a calm, glare-free background.
- **Surface Level 1 (Resting Cards & Tiles):** Pure white (`#FFFFFF`) with a hairline border (`1px solid #E2E8F0`) and an ambient, blue-tinted shadow (`box-shadow: 0 2px 8px -2px rgba(15, 23, 42, 0.04), 0 4px 16px -4px rgba(26, 104, 213, 0.06)`).
- **Surface Level 2 (Floating Action Buttons & Raised Controls):** Crisp white or primary solid fills elevated with directional depth (`box-shadow: 0 8px 24px -4px rgba(26, 104, 213, 0.25)`).
- **Surface Level 3 (Modals & Bottom Sheets):** Elevated pure white containers featuring a soft top lip radius, backed by a darkened scrim (`rgba(15, 23, 42, 0.4)` backdrop blur of `4px`). Elevated sheets use soft diffusion: `box-shadow: 0 -8px 32px rgba(15, 23, 42, 0.12)`.

## Shapes

The shape system employs roundedness level **2**, striking the ideal balance between clinical structure and physical comfort:

- **Cards & Primary Modules:** Configured at `16px` to `20px` corner radii (`rounded-lg` to `rounded-xl`), imparting a friendly, pebble-like handheld quality that removes clinical severity.
- **Interactive Controls (Inputs, Buttons):** Styled with `12px` to `16px` corners, maintaining consistent finger-target ergonomics.
- **Status Badges, Chips, and FABs:** Rendered in pure full-capsule pill radius (`9999px`) to immediately signal interactive category tags and system feedback chips.

## Components

### Buttons
- **Primary:** Filled in `#1A68D5`, text white, height 52px, border radius 14px. On tap, scales smoothly to 0.98 with background shifting to `#0D54CF`.
- **Secondary / Soft:** Sky blue tint `#EBF3FE` with `#1A68D5` text, height 52px, border radius 14px.
- **Destructive:** Rose wash `#FEE2E2` with `#EF4444` text.
- **Floating Action Button (FAB):** 56x56px circular or extended pill (48px height), background `#1A68D5`, crisp white iconography, elevated depth.

### Cards & Medical Records
- Pure `#FFFFFF` surface container, 16px-20px corner radius, framed with a 1px border `#E2E8F0`.
- Includes a dedicated header row (record category, date, and status pill), followed by a divider or 12px vertical spacing before metadata blocks (doctor name, dosage, diagnostic value).

### Chips & Badges
- **Status Badges:** Pill-shaped (`rounded-full`), horizontal padding 10px, vertical padding 4px.
  - Normal/Synced: `#E6F7F0` ground with `#059669` text and leading dot indicator.
  - Pending/Attention: `#FEF3C7` ground with `#D97706` text.
  - Critical/Abnormal: `#FEE2E2` ground with `#DC2626` text.
- **Filter Chips:** 36px height, pill shape, white ground, 1px `#E2E8F0` border. Active state shifts to `#EBF3FE` fill with a `#1A68D5` border and text.

### Form Inputs
- 52px height, 12px radius, `#FFFFFF` background, 1px `#CBD5E1` border. 
- Focused state transitions to a 2px `#1A68D5` ring with `#F8FAFC` background fill. 
- Validation error applies `#EF4444` border accompanied by an inline icon and assistive subtext.

### Lists & Timelines
- Clean list items separated by 8px margins on cards rather than full divider lines.
- Medical history timeline utilizes an anchored 2px vertical guide rail (`#E2E8F0`) with 12px pill nodes colored according to medical event type (visit, lab, prescription, procedure).

### Elevated Bottom Sheets
- Rounded top corners (24px radius), centered grab handle (36x4px, `#CBD5E1`), pure `#FFFFFF` background with subtle blur scrim. Houses multi-step entry forms, record detail drilldowns, and document share drawers.